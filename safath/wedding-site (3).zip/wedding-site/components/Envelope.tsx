"use client";

import { useState } from "react";

export default function Envelope({ onDone }: { onDone: () => void }) {
  const [open, setOpen] = useState(false);

  const openIt = () => {
    if (open) return;
    setOpen(true);
    setTimeout(onDone, 2800);
  };

  return (
    <div className="intro-bg fixed inset-0 z-50 flex flex-col items-center justify-center gap-12 overflow-hidden px-4 text-mist">
      <div className={`text-center transition-opacity duration-700 ${open ? "opacity-0" : "opacity-100"}`}>
        <p className="font-serif text-4xl italic sm:text-5xl">You have a wedding invitation</p>
        <p className="mt-2 text-mist/70">From Amara &amp; Daniel</p>
      </div>

      {/* Envelope */}
      <div
        className="relative aspect-[3/2] w-[min(88vw,440px)] drop-shadow-[0_30px_40px_rgba(0,0,0,.45)]"
        style={{ perspective: 1200 }}
      >
        {/* back */}
        <div className="absolute inset-0 rounded-md bg-[#0b1750]" />

        {/* invitation card inside */}
        <div
          className="absolute inset-x-[5%] top-[6%] z-10 flex h-[90%] flex-col items-center justify-center rounded-sm bg-paper text-night shadow-md transition-transform ease-out"
          style={{ transform: open ? "translateY(-62%)" : "translateY(0)", transitionDuration: "1.1s", transitionDelay: open ? ".7s" : "0s" }}
        >
          <span className="font-serif text-5xl italic">A &amp; D</span>
          <span className="mt-2 text-sm text-night/60">Please open with love</span>
        </div>

        {/* front pocket */}
        <div
          className="absolute inset-0 z-20 rounded-md bg-gradient-to-br from-[#2f55e0] to-[#1a34a0]"
          style={{ clipPath: "polygon(0 0, 50% 58%, 100% 0, 100% 100%, 0 100%)" }}
        />

        {/* flap */}
        <div
          className="absolute inset-0 bg-gradient-to-b from-[#4a70f0] to-[#2447c9]"
          style={{
            clipPath: "polygon(0 0, 100% 0, 50% 58%)",
            transformOrigin: "top",
            transform: open ? "rotateX(180deg)" : "rotateX(0deg)",
            zIndex: open ? 5 : 30,
            transition: "transform .8s ease-in-out, z-index 0s linear .4s",
          }}
        />

        {/* wax seal */}
        <button
          onClick={openIt}
          aria-label="Open the invitation"
          className={`absolute left-1/2 top-[58%] z-40 grid size-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-[radial-gradient(circle_at_35%_30%,#ffd978,#f5b731_60%,#b07c0a)] font-serif text-xl italic text-night shadow-lg transition duration-500 ${open ? "scale-50 opacity-0" : "hover:scale-110"}`}
        >
          {!open && <span className="seal-ring absolute inset-0 rounded-full border-2 border-marigold" />}
          A&amp;D
        </button>
      </div>

      <button
        onClick={openIt}
        className={`bob rounded-full border border-mist/50 px-8 py-3 text-lg transition hover:bg-mist hover:text-night ${open ? "pointer-events-none opacity-0" : "opacity-100"}`}
      >
        Click here to open
      </button>
    </div>
  );
}
