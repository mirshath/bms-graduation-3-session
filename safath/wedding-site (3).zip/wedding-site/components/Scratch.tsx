"use client";

import { useEffect, useRef, useState } from "react";

const COLORS = ["#f5b731", "#2447c9", "#eef1fb", "#ffd978", "#ffffff"];

export default function Scratch({ onEnter }: { onEnter: () => void }) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const drawing = useRef(false);
  const last = useRef<{ x: number; y: number } | null>(null);
  const moves = useRef(0);
  const [done, setDone] = useState(false);
  const [pieces] = useState(() =>
    Array.from({ length: 48 }, () => ({
      left: Math.random() * 100,
      delay: Math.random() * 1.2,
      dur: 2.6 + Math.random() * 2.2,
      size: 6 + Math.random() * 8,
      color: COLORS[Math.floor(Math.random() * COLORS.length)],
      round: Math.random() > 0.5,
    }))
  );

  useEffect(() => {
    const c = canvas.current!;
    const r = wrap.current!.getBoundingClientRect();
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    c.width = r.width * dpr;
    c.height = r.height * dpr;
    const ctx = c.getContext("2d")!;
    ctx.scale(dpr, dpr);
    const g = ctx.createLinearGradient(0, 0, r.width, r.height);
    g.addColorStop(0, "#d9b16f");
    g.addColorStop(0.35, "#f3dca4");
    g.addColorStop(0.6, "#b98d4f");
    g.addColorStop(1, "#e6c98a");
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, r.width, r.height);
    for (let i = 0; i < 300; i++) {
      ctx.fillStyle = `rgba(255,255,255,${Math.random() * 0.4})`;
      ctx.fillRect(Math.random() * r.width, Math.random() * r.height, 1.6, 1.6);
    }
    ctx.fillStyle = "#5e4118";
    ctx.textAlign = "center";
    ctx.font = "italic 32px Georgia, serif";
    ctx.fillText("Scratch to reveal", r.width / 2, r.height / 2);
    ctx.font = "15px sans-serif";
    ctx.fillText("use your finger or mouse", r.width / 2, r.height / 2 + 30);
  }, []);

  const point = (e: React.PointerEvent) => {
    const r = canvas.current!.getBoundingClientRect();
    return { x: e.clientX - r.left, y: e.clientY - r.top };
  };

  const check = () => {
    const c = canvas.current!;
    const data = c.getContext("2d")!.getImageData(0, 0, c.width, c.height).data;
    let clear = 0, total = 0;
    for (let i = 3; i < data.length; i += 64) {
      total++;
      if (data[i] < 128) clear++;
    }
    if (clear / total > 0.45) setDone(true);
  };

  const scratch = (e: React.PointerEvent) => {
    if (!drawing.current || done) return;
    const ctx = canvas.current!.getContext("2d")!;
    const p = point(e);
    ctx.globalCompositeOperation = "destination-out";
    ctx.lineWidth = 58;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(last.current?.x ?? p.x, last.current?.y ?? p.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
    last.current = p;
    if (++moves.current % 10 === 0) check();
  };

  return (
    <div className="intro-bg fixed inset-0 z-50 flex flex-col items-center justify-center gap-6 overflow-y-auto px-4 py-8 text-mist">
      {done && (
        <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden>
          {pieces.map((p, i) => (
            <span
              key={i}
              className="confetti"
              style={{
                left: `${p.left}%`,
                width: p.size,
                height: p.size * (p.round ? 1 : 0.45),
                borderRadius: p.round ? "50%" : 2,
                background: p.color,
                animationDelay: `${p.delay}s`,
                animationDuration: `${p.dur}s`,
              }}
            />
          ))}
        </div>
      )}

      <p className="fade-in font-serif text-3xl italic sm:text-4xl">
        {done ? "We are getting married!" : "Scratch the gold"}
      </p>

      <div className="fade-in w-[min(90vw,420px)] rounded-sm bg-paper p-3 text-night shadow-2xl">
        <div className="border border-marigold/60 p-2">
          <div ref={wrap} className="relative aspect-[4/5] select-none overflow-hidden bg-paper">
            {/* hidden content */}
            <div className="absolute inset-0 flex flex-col items-center justify-center px-6 text-center">
              <p className="text-sm text-night/70">Together with their families</p>
              <h2 className="mt-4 font-serif text-6xl font-light sm:text-7xl leading-[0.9]">
                Amara
                <span className="block italic text-marigold">&amp; Daniel</span>
              </h2>
              <div className="my-6 h-px w-24 bg-marigold/60" />
              <p className="font-serif text-3xl">Sunday, 14 March 2027</p>
              <p className="mt-2 text-night/70">4:00 pm, Villa Serena Gardens, Galle</p>
            </div>

            <canvas
              ref={canvas}
              className={`absolute inset-0 h-full w-full touch-none cursor-grab transition-opacity duration-1000 ${done ? "pointer-events-none opacity-0" : "opacity-100"}`}
              onPointerDown={(e) => {
                drawing.current = true;
                last.current = point(e);
                (e.target as HTMLElement).setPointerCapture(e.pointerId);
                scratch(e);
              }}
              onPointerMove={scratch}
              onPointerUp={() => { drawing.current = false; last.current = null; }}
              onPointerCancel={() => { drawing.current = false; last.current = null; }}
            />
          </div>
        </div>
      </div>

      <div className="h-14">
        {done ? (
          <button onClick={onEnter} className="fade-in rounded-full bg-marigold px-8 py-3 font-medium text-night transition hover:bg-mist">
            Open our wedding page
          </button>
        ) : (
          <button onClick={() => setDone(true)} className="text-sm text-mist/60 underline underline-offset-4 hover:text-mist">
            Skip
          </button>
        )}
      </div>
    </div>
  );
}
