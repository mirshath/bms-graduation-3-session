"use client";

import { useEffect, useRef, useState } from "react";
import Reveal from "./Reveal";

const WEDDING = new Date("2027-03-14T16:00:00");
const MAPS = "https://www.google.com/maps/search/?api=1&query=Villa+Serena+Gardens+Galle";

const schedule = [
  { time: "4:00", ap: "pm", title: "Ceremony", note: "Garden terrace. Please be seated by 3:45." },
  { time: "5:00", ap: "pm", title: "Cocktail hour", note: "Lemon groves with a live acoustic trio." },
  { time: "6:30", ap: "pm", title: "Dinner", note: "One long shared table under the pergola." },
  { time: "8:30", ap: "pm", title: "First dance and party", note: "Dancing until late." },
];

const faqs = [
  { q: "Where should we stay?", a: "The Grand Hotel is a 10-minute drive and has a wedding rate. Mention Amara & Daniel when you book." },
  { q: "How do we get to the venue?", a: "Shuttles leave the Grand Hotel at 3:00 pm and return at midnight. Parking is also available on site." },
  { q: "Can we bring children?", a: "Yes. Children are welcome, and there will be a supervised kids' corner during dinner." },
  { q: "What if it rains?", a: "The terrace has a covered pavilion, so the ceremony goes ahead either way." },
  { q: "Is there a gift registry?", a: "Your presence is the gift. If you would like to give something, a contribution to our honeymoon fund is welcome." },
];

// Replace any tile with a photo: <Image src="/p1.jpg" alt="" fill className="object-cover" /> and add "relative overflow-hidden" to its class
const tiles = [
  { s: "col-span-2 row-span-2", c: "rounded-t-[999px] bg-gradient-to-b from-marigold to-cobalt" },
  { s: "", c: "rounded-3xl bg-cobalt" },
  { s: "", c: "rounded-3xl bg-marigold" },
  { s: "col-span-2", c: "rounded-3xl bg-gradient-to-r from-night-soft to-cobalt" },
  { s: "", c: "rounded-full bg-mist" },
  { s: "col-span-2 md:col-span-3", c: "grid place-items-center rounded-3xl bg-night font-serif text-3xl italic text-marigold sm:text-5xl", t: "Forever starts here" },
];

function useCountdown() {
  const [left, setLeft] = useState<{ d: number; h: number; m: number; s: number } | null>(null);
  useEffect(() => {
    const tick = () => {
      const diff = Math.max(0, WEDDING.getTime() - Date.now());
      setLeft({
        d: Math.floor(diff / 864e5),
        h: Math.floor((diff / 36e5) % 24),
        m: Math.floor((diff / 6e4) % 60),
        s: Math.floor((diff / 1e3) % 60),
      });
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, []);
  return left;
}

/** Headline that fills in word by word as you scroll */
function ScrollWords({ text, className = "" }: { text: string; className?: string }) {
  const ref = useRef<HTMLHeadingElement>(null);
  const words = text.split(" ");
  useEffect(() => {
    const el = ref.current!;
    const spans = Array.from(el.children) as HTMLElement[];
    const update = () => {
      const vh = window.innerHeight;
      const p = Math.min(1, Math.max(0, (vh * 0.9 - el.getBoundingClientRect().top) / (vh * 0.5)));
      spans.forEach((s, i) => (s.style.opacity = p * spans.length > i ? "1" : "0.15"));
    };
    update();
    window.addEventListener("scroll", update, { passive: true });
    window.addEventListener("resize", update);
    return () => {
      window.removeEventListener("scroll", update);
      window.removeEventListener("resize", update);
    };
  }, []);
  return (
    <h2 ref={ref} className={className}>
      {words.map((w, i) => (
        <span key={i} className="transition-opacity duration-300" style={{ opacity: 0.15 }}>{w} </span>
      ))}
    </h2>
  );
}

function Letters({ text, start = 0 }: { text: string; start?: number }) {
  return (
    <span className="block overflow-hidden pb-[.12em]" aria-label={text}>
      {[...text].map((ch, i) => (
        <span key={i} aria-hidden className="lt inline-block" style={{ animationDelay: `${start + i * 0.06}s` }}>
          {ch === " " ? "\u00A0" : ch}
        </span>
      ))}
    </span>
  );
}

export default function Site({ onReplay }: { onReplay: () => void }) {
  const left = useCountdown();
  const main = useRef<HTMLElement>(null);
  const [scrolled, setScrolled] = useState(false);
  const ticker = "Amara & Daniel ✦ 14 March 2027 ✦ Villa Serena Gardens, Galle ✦ ";

  // one scroll listener feeds CSS variables used for parallax and the progress bar
  useEffect(() => {
    const el = main.current!;
    let raf = 0;
    const on = () => {
      cancelAnimationFrame(raf);
      raf = requestAnimationFrame(() => {
        const y = window.scrollY;
        const max = document.documentElement.scrollHeight - window.innerHeight;
        el.style.setProperty("--sy", String(y));
        el.style.setProperty("--sp", String(max > 0 ? y / max : 0));
        setScrolled(y > 60);
      });
    };
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("scroll", on);
    };
  }, []);

  const mouse = (e: React.MouseEvent<HTMLElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`);
    e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`);
  };

  return (
    <main ref={main} className="fade-in">
      <div className="fixed inset-x-0 top-0 z-[60] h-1 origin-left bg-marigold" style={{ transform: "scaleX(var(--sp, 0))" }} />

      {/* Header */}
      <header className={`fixed inset-x-0 top-0 z-50 flex items-center justify-between px-5 py-4 text-mist transition duration-500 md:px-10 ${scrolled ? "bg-night/85 backdrop-blur-md" : ""}`}>
        <span className="font-serif text-2xl italic">A &amp; D</span>
        <nav className="hidden gap-8 text-sm md:flex">
          <a href="#story" className="hover:text-marigold">Our story</a>
          <a href="#day" className="hover:text-marigold">The day</a>
          <a href="#details" className="hover:text-marigold">Details</a>
          <a href="#faq" className="hover:text-marigold">Guest info</a>
        </nav>
        <a href={MAPS} target="_blank" rel="noreferrer" className="shine rounded-full bg-marigold px-5 py-2 text-sm font-medium text-night">
          Directions
        </a>
      </header>

      {/* Hero */}
      <section onMouseMove={mouse} className="hero-bg relative overflow-hidden text-mist">
        <div className="glow pointer-events-none absolute inset-0 hidden md:block" />
        <div className="float pointer-events-none absolute -right-10 top-24 size-40 rounded-full border border-marigold/50 sm:size-64" />
        <div className="float pointer-events-none absolute bottom-24 left-[8%] size-6 rounded-full bg-marigold" style={{ animationDelay: "-2s" }} />
        <div className="float pointer-events-none absolute left-[46%] top-32 size-3 rounded-full bg-cobalt" style={{ animationDelay: "-4s" }} />

        <div className="mx-auto grid min-h-[100svh] max-w-7xl items-center gap-12 px-5 pb-20 pt-28 md:grid-cols-12 md:px-10 md:pb-28">
          <div className="px md:col-span-7" style={{ transform: "translateY(calc(var(--sy, 0) * .16px))" }}>
            <p className="fade-in text-sm text-marigold sm:text-base" style={{ animationDelay: ".1s" }}>Save the date: Sunday, 14 March 2027</p>
            <h1 className="mt-5 font-serif text-[clamp(4.2rem,19vw,9.5rem)] font-normal leading-[.85]">
              <Letters text="Amara" start={0.3} />
              <span className="block pl-[.35em] italic text-marigold"><Letters text="& Daniel" start={0.75} /></span>
            </h1>
            <p className="fade-in mt-8 max-w-md text-base leading-relaxed text-mist/75 sm:text-lg" style={{ animationDelay: "1.5s" }}>
              Two families, one long table and a weekend by the sea. Everything you need to know is on this page.
            </p>
            <div className="fade-in mt-9 flex flex-col gap-3 sm:flex-row" style={{ animationDelay: "1.8s" }}>
              <a href="#day" className="shine rounded-full bg-marigold px-8 py-3.5 text-center font-medium text-night">See the schedule</a>
              <a href="#faq" className="rounded-full border border-mist/40 px-8 py-3.5 text-center transition hover:border-marigold hover:text-marigold">Guest information</a>
            </div>
          </div>

          {/* Swap the gradient for <Image src="/couple.jpg" alt="Amara and Daniel" fill className="object-cover" /> */}
          <div className="px md:col-span-5" style={{ transform: "translateY(calc(var(--sy, 0) * -.07px))" }}>
            <div className="arch-reveal relative mx-auto aspect-[3/4] w-full max-w-[20rem] overflow-hidden rounded-t-full bg-gradient-to-b from-marigold via-cobalt to-night-soft ring-1 ring-marigold/70 ring-offset-8 ring-offset-night md:max-w-none">
              <span className="absolute inset-0 grid place-items-center font-serif text-7xl italic text-night/80 sm:text-8xl">A&amp;D</span>
            </div>
          </div>
        </div>
        <div className="absolute inset-x-0 bottom-6 hidden justify-center md:flex">
          <span className="bob text-sm text-mist/60">Scroll</span>
        </div>
      </section>

      {/* Tickers */}
      <div aria-hidden className="overflow-hidden bg-marigold py-3 text-night">
        <div className="marquee flex w-max whitespace-nowrap font-serif text-xl italic sm:text-2xl">
          {[0, 1, 2, 3].map((i) => <span key={i} className="pr-4">{ticker}</span>)}
        </div>
      </div>
      <div aria-hidden className="overflow-hidden bg-night py-3">
        <div className="marquee-rev flex w-max whitespace-nowrap font-serif text-3xl italic text-transparent [-webkit-text-stroke:1px_var(--color-mist)] sm:text-5xl">
          {[0, 1, 2, 3].map((i) => <span key={i} className="pr-4">{ticker}</span>)}
        </div>
      </div>

      {/* Countdown */}
      <section aria-label="Countdown" className="bg-mist px-4 py-14 sm:py-20">
        <Reveal variant="scale">
          <dl className="mx-auto grid max-w-3xl grid-cols-4 text-center">
            {(["d", "h", "m", "s"] as const).map((k, i) => (
              <div key={k} className={i ? "border-l border-night/15" : ""}>
                <dd key={left ? left[k] : "x"} className="tick font-serif text-4xl tabular-nums text-cobalt sm:text-6xl md:text-7xl">
                  {left ? String(left[k]).padStart(2, "0") : "--"}
                </dd>
                <dt className="mt-1 text-xs text-night/60 sm:text-sm">{["days", "hours", "minutes", "seconds"][i]}</dt>
              </div>
            ))}
          </dl>
        </Reveal>
      </section>

      {/* Story + gallery */}
      <section id="story" className="mx-auto max-w-6xl px-5 py-20 sm:py-28 md:px-10">
        <div className="grid gap-10 md:grid-cols-12 md:gap-16">
          <ScrollWords
            text="Six years, two cities, one very long walk home."
            className="font-serif text-4xl leading-[1.05] sm:text-5xl md:col-span-5 md:text-6xl"
          />
          <div className="space-y-5 text-lg leading-relaxed text-night/75 md:col-span-7 md:text-xl">
            <Reveal><p>We met at a friend's rooftop dinner in Colombo and argued about the best kottu in town until the candles burned out.</p></Reveal>
            <Reveal delay={0.12}><p>Daniel proposed on a quiet beach in Mirissa, with the ring hidden inside a packet of Amara's favourite biscuits.</p></Reveal>
            <Reveal delay={0.24}><p>Now we would love you beside us for the next chapter.</p></Reveal>
          </div>
        </div>

        <div className="mt-14 grid auto-rows-[7rem] grid-flow-dense grid-cols-2 gap-3 sm:auto-rows-[10rem] md:grid-cols-4 md:gap-4">
          {tiles.map((t, i) => (
            <Reveal key={i} variant={i % 2 ? "right" : "scale"} delay={i * 0.08} className={`${t.s} overflow-hidden`}>
              <div className={`${t.c} h-full w-full transition duration-700 hover:scale-105 hover:-rotate-1`}>{t.t}</div>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Schedule */}
      <section id="day" className="bg-night px-5 py-20 text-mist sm:py-28 md:px-10">
        <div className="mx-auto max-w-4xl">
          <Reveal><h2 className="font-serif text-5xl sm:text-7xl">The day</h2></Reveal>
          <div className="mt-12">
            {schedule.map((s, i) => (
              <Reveal key={s.title} variant="left" delay={i * 0.08}>
                <div className="grid grid-cols-[5.5rem_1fr] gap-4 border-t border-mist/20 py-7 transition-all duration-500 hover:bg-white/5 hover:pl-4 sm:grid-cols-[10rem_1fr] sm:gap-8">
                  <p className="font-serif text-4xl text-marigold sm:text-6xl">{s.time}<span className="ml-1 text-base sm:text-xl">{s.ap}</span></p>
                  <div>
                    <h3 className="font-serif text-2xl sm:text-4xl">{s.title}</h3>
                    <p className="mt-1 text-mist/70">{s.note}</p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* Details */}
      <section id="details" className="mx-auto max-w-6xl px-5 py-20 sm:py-28 md:px-10">
        <div className="grid gap-5 md:grid-cols-3">
          <Reveal variant="left">
            <div className="h-full rounded-3xl bg-cobalt p-8 text-mist transition duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-cobalt/40">
              <h3 className="font-serif text-3xl">Venue</h3>
              <p className="mt-3 leading-relaxed text-mist/85">Villa Serena Gardens, 12 Orchard Lane, Galle</p>
              <a href={MAPS} target="_blank" rel="noreferrer" className="shine mt-6 inline-block rounded-full bg-marigold px-6 py-2.5 text-sm font-medium text-night">Open in Maps</a>
            </div>
          </Reveal>
          <Reveal variant="right" className="md:col-span-2">
            <div className="h-full rounded-3xl bg-mist p-8 transition duration-500 hover:-translate-y-2 hover:shadow-2xl hover:shadow-night/15">
              <h3 className="font-serif text-3xl">Dress code: garden formal</h3>
              <p className="mt-3 max-w-lg leading-relaxed text-night/75">Light fabrics and comfortable shoes for the lawn. Our colors are below, and you are welcome to wear them.</p>
              <div className="mt-6 flex gap-3">
                {["bg-cobalt", "bg-marigold", "bg-night", "bg-white ring-1 ring-night/15"].map((c) => (
                  <span key={c} className={`size-12 rounded-full transition duration-300 hover:scale-125 sm:size-14 ${c}`} />
                ))}
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* Guest info */}
      <section id="faq" className="mx-auto max-w-3xl px-5 pb-20 sm:pb-28">
        <Reveal><h2 className="font-serif text-4xl sm:text-5xl">Guest information</h2></Reveal>
        <div className="mt-8">
          {faqs.map((f, i) => (
            <Reveal key={f.q} delay={i * 0.06}>
              <details className="group border-b border-night/15 py-5">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 text-lg font-medium [&::-webkit-details-marker]:hidden">
                  {f.q}
                  <span className="text-3xl leading-none text-cobalt transition group-open:rotate-45">+</span>
                </summary>
                <p className="mt-3 max-w-xl leading-relaxed text-night/70">{f.a}</p>
              </details>
            </Reveal>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="overflow-hidden bg-cobalt px-5 py-20 text-center text-mist">
        <Reveal variant="scale">
          <p className="font-serif text-[clamp(3rem,13vw,9rem)] italic leading-none">Amara &amp; Daniel</p>
        </Reveal>
        <p className="mt-6 text-mist/80">14 March 2027, Galle</p>
        <button onClick={onReplay} className="shine mt-8 rounded-full border border-mist/50 px-6 py-2.5 text-sm transition hover:bg-mist hover:text-night">
          Replay the invitation
        </button>
      </footer>
    </main>
  );
}
