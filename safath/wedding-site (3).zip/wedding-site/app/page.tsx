"use client";

import { useState } from "react";
import Envelope from "@/components/Envelope";
import Scratch from "@/components/Scratch";
import Site from "@/components/Site";

export default function Page() {
  const [stage, setStage] = useState<"envelope" | "scratch" | "site">("envelope");
  const go = (s: typeof stage) => {
    setStage(s);
    window.scrollTo(0, 0);
  };

  if (stage === "envelope") return <Envelope onDone={() => go("scratch")} />;
  if (stage === "scratch") return <Scratch onEnter={() => go("site")} />;
  return <Site onReplay={() => go("envelope")} />;
}
