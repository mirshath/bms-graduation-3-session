import type { Metadata, Viewport } from "next";
import { Bodoni_Moda, DM_Sans } from "next/font/google";
import "./globals.css";

const serif = Bodoni_Moda({
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  style: ["normal", "italic"],
  variable: "--font-bodoni",
});
const sans = DM_Sans({ subsets: ["latin"], variable: "--font-dm" });

export const metadata: Metadata = {
  title: "Amara & Daniel · 14 March 2027",
  description: "You're invited to our wedding. Schedule, venue and guest information.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0e1638" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${serif.variable} ${sans.variable}`}>
      <body className="overflow-x-hidden bg-paper font-sans text-night antialiased">{children}</body>
    </html>
  );
}
