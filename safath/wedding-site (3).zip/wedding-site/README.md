# Wedding invitation site (Next.js + Tailwind CSS v4)

npm install
npm run dev      -> http://localhost:3000
npm run build && npm start   -> production

Edit names/date/venue in components/Site.tsx, Scratch.tsx, Envelope.tsx. Colors in app/globals.css (@theme).
